/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package admin;

import com.wanda.project_tiket.db;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.Timer;

/**
 *
 * @author asus
 */
public class Event extends javax.swing.JFrame {

    /**
     * Creates new form Admin
     */
    
    public Event() {
        initComponents();
        loadfasilitas();
        loadjadwal();
       loadKonser();
       loadfasilitaskonser();
       loadJadwalKonser();
        Timer timer = new Timer(2000, new ActionListener() {
       
        public void actionPerformed(ActionEvent e) {
           loadfasilitas();
           loadKonser();
           loadjadwal();
        }
    });
    
    timer.start(); // Mulai timer

    }
    // Method untuk memuat data fasilitas ke dalam ComboBox
private void loadfasilitaskonser() {
    try {
        Connection conn = db.mycon();
        
        String sql = "SELECT nama_fasilitas FROM fasilitas"; 
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        fasilitaskonser.removeAllItems();  // Menghapus item sebelumnya di ComboBox

        // Menambahkan item baru ke dalam ComboBox
        while (rs.next()) {
            fasilitaskonser.addItem(rs.getString("nama_fasilitas"));  // Menambahkan nama fasilitas ke ComboBox
        }

        rs.close();
        ps.close();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Gagal memuat fasilitas: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

// Method untuk mendapatkan ID fasilitas yang dipilih
private String getSelectedFasilitasId() {
    // Ambil item yang dipilih dari ComboBox
    String namaDipilih = (String) fasilitaskonser.getSelectedItem();
    String idFasilitas = null;

    if (namaDipilih != null) {
        try {
            Connection conn = db.mycon();
            String sql = "SELECT fasilitas_id FROM fasilitas WHERE nama_fasilitas = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, namaDipilih);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                idFasilitas = rs.getString("fasilitas_id");
            }

            rs.close();
            ps.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    return idFasilitas;
}

private void loadJadwalKonser() {
    try {
        Connection conn = db.mycon();
        
        String sql = "SELECT tanggal FROM jadwal"; 
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        jadwalkonser.removeAllItems();  // Menghapus item sebelumnya di ComboBox

        // Menambahkan item baru ke dalam ComboBox
        while (rs.next()) {
            jadwalkonser.addItem(rs.getString("tanggal"));  // Menambahkan nama jadwal ke ComboBox
        }

        rs.close();
        ps.close();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Gagal memuat jadwal: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

// Method untuk mendapatkan ID jadwal yang dipilih
private String getSelectedJadwalId() {
    // Ambil item yang dipilih dari ComboBox
    String namaDipilih = (String) jadwalkonser.getSelectedItem();
    String idJadwal = null;

    if (namaDipilih != null) {
        try {
            Connection conn = db.mycon();
            String sql = "SELECT jadwal_id FROM jadwal WHERE tanggal = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, namaDipilih);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                idJadwal = rs.getString("jadwal_id");
            }

            rs.close();
            ps.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    return idJadwal;
}

    
    private void loadKonser() {
    try {
        // Membuka koneksi ke database
        Connection conn = db.mycon();
        Statement stmt = conn.createStatement();

        // Query untuk mengambil data konser dari tabel konser
        String query = """
            SELECT konser_id, nama_konser, fasilitas_id, nama_musisi, id_jadwal, harga_tiket
            FROM konser;
        """;
        
        ResultSet rs = stmt.executeQuery(query);

        // Mengosongkan tabel terlebih dahulu
        DefaultTableModel model = (DefaultTableModel) konser.getModel();  // Ganti 'konserTable' dengan nama objek tabel Anda
        model.setRowCount(0);  // Menghapus semua baris dalam tabel

        // Mengisi tabel dengan data dari database
        while (rs.next()) {
            // Menambahkan data ke tabel konser
            Object[] rowData = new Object[6];
            rowData[0] = rs.getInt("konser_id");         // konser_id
            rowData[1] = rs.getString("nama_konser");    // nama_konser
            rowData[2] = rs.getInt("fasilitas_id");      // fasilitas_id
            rowData[3] = rs.getString("nama_musisi");    // nama_musisi
            rowData[4] = rs.getInt("id_jadwal");         // id_jadwal
            rowData[5] = rs.getBigDecimal("harga_tiket");  // harga_tiket

            // Menambahkan baris ke model tabel
            model.addRow(rowData);
        }


    } catch (SQLException e) {
        System.out.println("Error: " + e.getMessage());
    }
}

    
    private void loadjadwal() {
    try {
        // Membuka koneksi ke database
        Connection conn = db.mycon();
        Statement stmt = conn.createStatement();

        // Query untuk mengambil data dari tabel jadwal
        String query = "SELECT * FROM jadwal";

        // Menjalankan query dan mengambil hasilnya
        ResultSet rs = stmt.executeQuery(query);

        // Mengosongkan tabel sebelum mengisi data baru
        DefaultTableModel model = (DefaultTableModel) jadwal.getModel(); // Ganti dengan nama objek tabel Anda
        model.setRowCount(0); // Menghapus semua baris dalam tabel

        // Mengisi tabel dengan data dari hasil query
        while (rs.next()) {
            Object[] rowData = new Object[4];
            rowData[0] = rs.getInt("jadwal_id");   // jadwal_id
            rowData[1] = rs.getDate("tanggal");    // tanggal
            rowData[2] = rs.getString("jam");      // jam
            rowData[3] = rs.getString("lokasi");   // lokasi
            model.addRow(rowData);  // Menambahkan baris data ke dalam tabel
        }

    } catch (SQLException e) {
        System.out.println("Error: " + e.getMessage());
    }
}

    public void loadfasilitas() {
        try {
        
        // Membuka koneksi database
        Connection conn = db.mycon();
        Statement stmt = conn.createStatement();
        
        // Query untuk mengambil data dari tabel fasilitas
        String query = "SELECT * FROM fasilitas"; // Sesuaikan dengan nama tabel dan kolom Anda
        
        ResultSet rs = stmt.executeQuery(query);
        
        // Mengosongkan tabel terlebih dahulu sebelum mengisi data baru
        DefaultTableModel model = (DefaultTableModel) fasilitas.getModel(); // Ganti dengan nama objek JTable Anda
        model.setRowCount(0); // Menghapus semua baris dalam tabel
        
        // Mengisi tabel dengan data yang diambil
        while (rs.next()) {
            // Menambahkan data ke tabel fasilitas di GUI (misalnya menggunakan DefaultTableModel)
            Object[] rowData = new Object[2]; // Sesuaikan jumlah kolom dengan jumlah data yang ingin ditampilkan
            rowData[0] = rs.getInt("fasilitas_id"); // id_fasilitas (misalnya, kolom ID)
            rowData[1] = rs.getString("nama_fasilitas"); // nama_fasilitas (misalnya, kolom nama fasilitas)
            
            model.addRow(rowData); // Menambahkan data ke tabel
        }

    } catch (SQLException e) {
        System.out.println("Error: " + e.getMessage());
    }
    }
    
    // Tambahkan kode untuk menampilkan fasilitasTable di dalam UI (misa


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        fasilitas = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        nama = new javax.swing.JTextField();
        save = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jTabbedPane4 = new javax.swing.JTabbedPane();
        jScrollPane8 = new javax.swing.JScrollPane();
        jScrollPane9 = new javax.swing.JScrollPane();
        jadwal = new javax.swing.JTable();
        jPanel10 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        tanggal = new javax.swing.JTextField();
        save3 = new javax.swing.JButton();
        jam = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        lokasi = new javax.swing.JTextArea();
        jLabel10 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jScrollPane3 = new javax.swing.JScrollPane();
        jScrollPane4 = new javax.swing.JScrollPane();
        konser = new javax.swing.JTable();
        jPanel6 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        save1 = new javax.swing.JButton();
        jScrollPane10 = new javax.swing.JScrollPane();
        namamusisi = new javax.swing.JTextArea();
        namakonser = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        harga = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jadwalkonser = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        fasilitaskonser = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(53, 50, 188));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jPanel2.setBackground(new java.awt.Color(53, 50, 188));

        jButton1.setText("Dashboard");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Pelanggan");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton5.setText("Laporan");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setText("Keluar");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setText("Event");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addComponent(jButton1)
                .addGap(31, 31, 31)
                .addComponent(jButton7)
                .addGap(34, 34, 34)
                .addComponent(jButton2)
                .addGap(34, 34, 34)
                .addComponent(jButton5)
                .addGap(40, 40, 40)
                .addComponent(jButton6)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Fasilitas");

        fasilitas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Id", "Fasilitas"
            }
        ));
        jScrollPane1.setViewportView(fasilitas);

        jScrollPane2.setViewportView(jScrollPane1);

        jTabbedPane1.addTab("Tabel", jScrollPane2);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setText("Nama");

        nama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                namaActionPerformed(evt);
            }
        });

        save.setText("Save");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(save)
                    .addComponent(nama, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addContainerGap(261, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nama, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(save)
                .addContainerGap(70, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Form", jPanel4);

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setText("Jadwal");

        jadwal.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Id", "tanggal", "jam", "lokasi"
            }
        ));
        jScrollPane9.setViewportView(jadwal);
        if (jadwal.getColumnModel().getColumnCount() > 0) {
            jadwal.getColumnModel().getColumn(3).setHeaderValue("lokasi");
        }

        jScrollPane8.setViewportView(jScrollPane9);

        jTabbedPane4.addTab("Tabel", jScrollPane8);

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));

        jLabel8.setText("Tanggal");

        tanggal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tanggalActionPerformed(evt);
            }
        });

        save3.setText("Save");
        save3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save3ActionPerformed(evt);
            }
        });

        jam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jamActionPerformed(evt);
            }
        });

        jLabel9.setText("Jam");

        lokasi.setColumns(20);
        lokasi.setRows(5);
        jScrollPane5.setViewportView(lokasi);

        jLabel10.setText("Lokasi");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(save3)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tanggal, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jam, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9)))
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 418, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(45, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tanggal, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jam, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(save3)
                .addGap(80, 80, 80))
        );

        jTabbedPane4.addTab("Form", jPanel10);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jTabbedPane4)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 271, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jTabbedPane1)
            .addComponent(jPanel9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 251, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Konser");

        konser.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Nama", "Id Fasilitas", "Nama Musisi", "Id Jadwal", "Harga"
            }
        ));
        jScrollPane4.setViewportView(konser);

        jScrollPane3.setViewportView(jScrollPane4);

        jTabbedPane2.addTab("Tabel", jScrollPane3);

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        jLabel4.setText("Nama Konser");

        save1.setText("Save");
        save1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save1ActionPerformed(evt);
            }
        });

        namamusisi.setColumns(20);
        namamusisi.setRows(5);
        jScrollPane10.setViewportView(namamusisi);

        namakonser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                namakonserActionPerformed(evt);
            }
        });

        jLabel13.setText("Nama Musisi");

        harga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hargaActionPerformed(evt);
            }
        });

        jLabel11.setText("Harga");

        jLabel12.setText("Jadwal");

        jadwalkonser.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel14.setText("Fasilitas");

        fasilitaskonser.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel14)
                    .addComponent(jLabel12)
                    .addComponent(jLabel11)
                    .addComponent(jLabel4)
                    .addComponent(jLabel13)
                    .addComponent(save1)
                    .addComponent(namakonser)
                    .addComponent(jScrollPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
                    .addComponent(harga, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jadwalkonser, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fasilitaskonser, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(129, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(namakonser, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(harga, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jadwalkonser, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(fasilitaskonser, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(save1)
                .addContainerGap(41, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Form", jPanel6);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 496, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane2))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void namaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_namaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_namaActionPerformed

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
        // TODO add your handling code here:
        String namaFasilitas = nama.getText(); // Gantilah namaFasilitasTextField dengan nama objek input Anda
    
    // Validasi input (pastikan nama fasilitas tidak kosong)
    if (namaFasilitas.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Nama fasilitas tidak boleh kosong.");
        return;
    }

    try {
        // Membuka koneksi database
        Connection conn = db.mycon();
        
        // Query untuk menyimpan data ke tabel fasilitas
        String query = "INSERT INTO fasilitas (nama_fasilitas) VALUES (?)";
        
        // Menyiapkan statement untuk menyimpan data
        PreparedStatement ps = conn.prepareStatement(query);
        ps.setString(1, namaFasilitas);  // Menyeting nama fasilitas
        
        // Menjalankan query untuk menyimpan data
        int rowsInserted = ps.executeUpdate();

        // Mengecek apakah data berhasil disimpan
        if (rowsInserted > 0) {
            JOptionPane.showMessageDialog(this, "Fasilitas berhasil disimpan.");
        } else {
            JOptionPane.showMessageDialog(this, "Terjadi kesalahan saat menyimpan fasilitas.");
        }

    } catch (SQLException e) {
        // Menangani error jika terjadi kesalahan saat eksekusi
        System.out.println("Error: " + e.getMessage());
        JOptionPane.showMessageDialog(this, "Terjadi kesalahan saat menyimpan data fasilitas.");
    }
    }//GEN-LAST:event_saveActionPerformed

    private void save1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save1ActionPerformed
        String namaKonser = namakonser.getText(); // Asumsi Anda punya JTextField dengan nama namaKonserTextField
    String namaMusisi = namamusisi.getText(); // Asumsi Anda punya JTextField dengan nama namaMusisiTextField
    String hargaTiket = harga.getText(); // Asumsi Anda punya JTextField dengan nama hargaTiketTextField
    String fasilitasId = getSelectedFasilitasId(); // Mendapatkan fasilitas_id dari ComboBox (gunakan getSelectedFasilitasId)
    String jadwalId = getSelectedJadwalId(); // Mendapatkan id_jadwal dari ComboBox (gunakan getSelectedJadwalId)

    // Validasi jika ada input yang kosong
    if (namaKonser.isEmpty() || namaMusisi.isEmpty() || hargaTiket.isEmpty() || fasilitasId == null || jadwalId == null) {
        JOptionPane.showMessageDialog(this, "Semua kolom harus diisi!", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    try {
        // Menyimpan data ke tabel konser
        Connection conn = db.mycon();
        String sql = "INSERT INTO konser (nama_konser, fasilitas_id, nama_musisi, id_jadwal, harga_tiket) "
                   + "VALUES (?, ?, ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);

        // Menetapkan nilai-nilai pada PreparedStatement
        ps.setString(1, namaKonser);
        ps.setString(2, fasilitasId); // Menggunakan fasilitas_id yang dipilih dari ComboBox
        ps.setString(3, namaMusisi);
        ps.setString(4, jadwalId); // Menggunakan id_jadwal yang dipilih dari ComboBox
        ps.setString(5, hargaTiket);

        // Menjalankan query
        int rowsAffected = ps.executeUpdate();

        // Mengecek jika data berhasil disimpan
        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(this, "Data konser berhasil disimpan!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Gagal menyimpan data konser.", "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Menutup koneksi
        ps.close();
        

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_save1ActionPerformed

    private void tanggalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tanggalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tanggalActionPerformed

    private void save3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save3ActionPerformed
        // TODO add your handling code here:
     String tanggalDate = tanggal.getText();  // Misalnya tanggal adalah komponen JDateChooser atau JTextField
    String jam1 = jam.getText();              // Misalnya jam adalah komponen JTextField
    String lokasi1 = lokasi.getText();        // Misalnya lokasi adalah komponen JTextField

    // Validasi input: Pastikan tidak ada yang kosong
    if (tanggalDate == null || tanggalDate.isEmpty() || jam1.isEmpty() || lokasi1.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Harap lengkapi semua kolom.");
        return;
    }

    try {
        // Mengonversi String tanggal menjadi java.sql.Date
        java.sql.Date tanggal = java.sql.Date.valueOf(tanggalDate);  // Format tanggal yang benar: YYYY-MM-DD

        // Mengonversi String jam menjadi java.sql.Time
        java.sql.Time jam = java.sql.Time.valueOf(jam1);  // Pastikan jam dalam format HH:mm:ss

        // Membuka koneksi ke database
        Connection conn = db.mycon();
        
        // Query untuk menyimpan data ke dalam tabel jadwal
        String query = "INSERT INTO jadwal (tanggal, jam, lokasi) VALUES (?, ?, ?)";
        
        // Menyiapkan PreparedStatement
        PreparedStatement ps = conn.prepareStatement(query);
        
        // Menyeting parameter dengan tipe yang sesuai
        ps.setDate(1, tanggal);   // Menyeting tanggal dengan java.sql.Date
        ps.setTime(2, jam);       // Menyeting jam dengan java.sql.Time
        ps.setString(3, lokasi1); // Menyeting lokasi dengan String
        
        // Menjalankan query untuk menyimpan data
        int rowsAffected = ps.executeUpdate();
        
        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(this, "Data berhasil disimpan.");
        } else {
            JOptionPane.showMessageDialog(this, "Gagal menyimpan data.");
        }
        
        // Menutup koneksi
        
        
    } catch (SQLException e) {
        System.out.println("Error: " + e.getMessage());
        JOptionPane.showMessageDialog(this, "Terjadi kesalahan saat menyimpan data.");
    } catch (IllegalArgumentException e) {
        // Menangani kesalahan jika format tanggal atau jam salah
        JOptionPane.showMessageDialog(this, "Format tanggal atau jam tidak valid.");
    }
    }//GEN-LAST:event_save3ActionPerformed

    private void jamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jamActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jamActionPerformed

    private void namakonserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_namakonserActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_namakonserActionPerformed

    private void hargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_hargaActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        new Admin().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        new Pelanggan().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        new Laporan().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        this.setVisible(true);
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        new login1().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton6ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Event.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Event.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Event.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Event.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Event().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable fasilitas;
    private javax.swing.JComboBox<String> fasilitaskonser;
    private javax.swing.JTextField harga;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTabbedPane jTabbedPane4;
    private javax.swing.JTable jadwal;
    private javax.swing.JComboBox<String> jadwalkonser;
    private javax.swing.JTextField jam;
    private javax.swing.JTable konser;
    private javax.swing.JTextArea lokasi;
    private javax.swing.JTextField nama;
    private javax.swing.JTextField namakonser;
    private javax.swing.JTextArea namamusisi;
    private javax.swing.JButton save;
    private javax.swing.JButton save1;
    private javax.swing.JButton save3;
    private javax.swing.JTextField tanggal;
    // End of variables declaration//GEN-END:variables
}
