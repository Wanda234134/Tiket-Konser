/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.wanda.project_tiket;

/**
 *
 * @author THINKPAD P50S
 */
public class Project_Tiket {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
