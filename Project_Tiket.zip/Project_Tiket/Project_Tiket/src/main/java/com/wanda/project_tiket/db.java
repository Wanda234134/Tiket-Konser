package com.wanda.project_tiket;

import com.mysql.jdbc.Driver; // Import MySQL Driver
import java.sql.Connection;   // Import Kelas untuk Koneksi
import java.sql.DriverManager; // Import Driver Manager
import java.sql.SQLException; // Import untuk Menangani Error SQL

public class db {
    
    // Variabel statis untuk menyimpan koneksi database
    private static Connection conn;

    // Method untuk koneksi ke database
    public static Connection mycon() {
        if (conn == null) { // Jika koneksi belum ada, maka buat koneksi
            try {
                // Konfigurasi koneksi database
                String url = "jdbc:mysql://localhost:3306/tiketkonser"; // Nama database
                String user = "root"; // Username database (default MySQL)
                String password = ""; // Password database (kosong jika tidak ada)

                // Registrasi driver MySQL
                Driver driver = new Driver();
                DriverManager.registerDriver(driver);
                
                // Membuat koneksi ke database
                conn = DriverManager.getConnection(url, user, password);
                System.out.println("Koneksi ke database 'tiketkonser' Berhasil");
                
            } catch (SQLException ex) {
                // Menangani error koneksi
                System.out.println("Koneksi Gagal: " + ex.getMessage());
            }
        }
        return conn; // Mengembalikan objek koneksi
    }
    
    // Main method untuk uji koneksi
    public static void main(String[] args) {
        // Menguji koneksi
        mycon();
    }
}
